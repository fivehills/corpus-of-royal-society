####POS-3gram#########
## the code run on the Linux terminal and R respectively

#######Setp 1: perform in Linux terminal
##use bash terminal to make it
## preprocessing: remove unneccessary xml tags in corpus of royal society
## form clean text
## here the text only contains two columns: words and POS
#1	a	DT
#2	discourse	NN
#3	Concernimg	NP
#4	GRAVIT	NP
#5	Y	NP
#6	,	,
#7	and	CC
#8	its	PP$
#9	Properties	NPS
#10	,	,

$ tail +2 w1800.txt > w2s
$ wc w2s
#1428233  2856466 11690757 w2s
$ paste w1850.txt w2s | head -1428233>w12s
$ tail +3 w1850.txt>w3s
$ wc w3s
#1428232  2856464 11690747 w3s
 
##form POS trigram
$ paste w12s w3s|head -4579473>w123s
$ awk '{print $2, $4, $6}' w123s | sort | uniq -c|sort -nr|head -5
  #41588 IN DT NN
  #30797 DT NN IN
  #26977 NN IN DT
  #26462 DT JJ NN
  #22038 IN DT JJ

$ awk '{print $2, $4, $6}' w123s | sort | uniq -c|sort -nr > pos1800.txt


## remove all lines containing punctuation 
$ grep -vwE "([[:punct:]])" pos1800.txt > pos1800p.txt

## merge the latter three columns into one by "_"
$ awk '{print $2"_"$3"_"$4"\t"$1}' < pos1800p.txt>pos1800s.txt

## remove lines with strings with these symbols in the first column
$ awk '$1 !~ /SENT|CD|SYM/' pos1800s.txt > pp1800.txt

## sum all frequency
$ awk -F' ' '{sum+=$2}END{print sum;}' pp1800.txt
#791916
## add one column with the standard frequency(one million）
$ awk '{print $2, $1,  $2*1000000/791916}'  pp1800.txt >ps1800.txt

## the same method is used to create the other file "ps1810.txt"
## merge two files according to their shared POS trigram forms 
## V1=raw freq in 1800, V2=POStrigram, V3=standard freq in 1810, V4=standard freq in 1810

$ awk 'FNR==NR{a[$2]=$3;next}{ print $0,a[$2]}' ps1800.txt ps1810.txt>ps18100.txt

#41588 IN_DT_NN 52515.7 54298.1
#30797 DT_NN_IN 38889.2 42012.1
#26977 NN_IN_DT 34065.5 36957.5
#26462 DT_JJ_NN 33415.2 33311.7
#22038 IN_DT_JJ 27828.7 26541.4


###########Step 2: perform in R

###enter R


##read all files into R
w1710=read.delim("ps17100.txt", header=FALSE, sep=" ", stringsAsFactor=FALSE)
w1720=read.delim("ps17210.txt", header=FALSE, sep=" ", stringsAsFactor=FALSE)
...
w1800=read.delim("ps18090.txt", header=FALSE, sep=" ", stringsAsFactor=FALSE)
w1810=read.delim("ps18100.txt", header=FALSE, sep=" ", stringsAsFactor=FALSE)
w1820=read.delim("ps18210.txt", header=FALSE, sep=" ", stringsAsFactor=FALSE)
w1830=read.delim("ps18320.txt", header=FALSE, sep=" ", stringsAsFactor=FALSE)
w1840=read.delim("ps18430.txt", header=FALSE, sep=" ", stringsAsFactor=FALSE)

## Create the most frequent and common POS trigram forms by the use of "intersect"
## name these POS trigrams as "stopword"
## remove these POS trigrams from each text

stopword=read.delim("stopword", header=FALSE, stringsAsFactor=FALSE)
stopword=stopword$V1

library(tm)

w1710$V2=as.character(w1710$V2)
x=w1710$V2
x=removeWords(x,stopword)
w1710$V2=x
w1720$V2=as.character(w1720$V2)
x=w1720$V2
x=removeWords(x,stopword)
w1720$V2=x
....
x=w1800$V2
x=removeWords(x,stopword)
w1800$V2=x
x=w1810$V2
x=removeWords(x,stopword)
w1810$V2=x
x=w1820$V2
x=removeWords(x,stopword)
w1820$V2=x
x=w1830$V2
x=removeWords(x,stopword)
w1830$V2=x
x=w1840$V2
x=removeWords(x,stopword)
w1840$V2=x


## filter data according to the frequency difference
w1800s=w1800[which((w1800$V4-w1800$V3)>20),]
w1810s=w1810[which((w1810$V4-w1810$V3)>2),]

##remove blanket lines
w1810s=w1810s[which(w1810s$V2 !=""),]
w1820s=w1820s[which(w1820s$V2 !=""),]

head(w1810s)
#     V1         V2      V3      V4
#52 1717   JJ_NN_NN 2168.16 2472.62
#54 1694 NN_VBZ_VVN 2139.12 2586.16
#56 1685   NN_MD_VB 2127.75 2360.48
#64 1579  IN_NNS_IN 1993.90 2361.88
#72 1506   DT_NN_MD 1901.72 1948.38
#77 1452   IN_NN_CC 1833.53 1864.28

##Welch t-test

t.test(w1810s$V3, w1810s$V4)

#	Welch Two Sample t-test

#data:  w1810s$V3 and w1810s$V4
#t = -2.7918, df = 5186.5, p-value = 0.005261
#alternative hypothesis: true difference in means is not equal to 0
#95 percent confidence interval:
# -29.348432  -5.134439
#sample estimates:
#mean of x mean of y 
# 80.24656  97.48800



########Step 3: Calculate relative entropy

##function of entropy

 info <- function(CLASS.FREQ){
      freq.class <- CLASS.FREQ
      info <- 0
      for(i in 1:length(freq.class)){
        if(freq.class[[i]] != 0){ # zero check in class
          entropy <- -sum(freq.class[[i]] * log2(freq.class[[i]]))  #I calculate the entropy for each class i here
        }else{ 
          entropy <- 0
        } 
        info <- info + entropy # sum up entropy from all classes
      }
      return(info)
    }
    
##calculate relative entropy

enw=info(w1810s$V3/sum(w1810s$V3))
#9.345688
enwp=info(w1810s$V4/sum(w1810s$V4))
#9.602644

rlen1800=enwp-enw
#0.2569567

######repeat the procedure for different periods


###########Step 4: Plot in R (with the data on relative entropy of lemmas)

#setEPS()
#postscript("relative_entropy.eps", height=3, width=5)



par(mfrow=c(1,2))


plot(re[,1], re[,2],  type="l", col="blue", lwd=2, xlab="decades", ylab="KLD", main="POS trigram", cex.lab=0.5, cex.axis=0.5, cex.main=0.5)

plot(re[,1], re[,3],  type="l", col="red", lwd=2, ylim=c(0.35, 0.65),xlab="decades", ylab="KLD", main="lemma", cex.lab=0.5, cex.axis=0.5, cex.main=0.5)

dev.off ()

