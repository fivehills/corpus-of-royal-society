
## calcuate relative entropy for lemmas over different decades

## the code run on the Linux terminal and R respectively

##########Step 1: perform on terminal

## remove these words containing any digits, special symbols to obtain pure words
## frequency list 
## V1= raw freq, V2=lemma, V3=standard freq (one million)

awk '{print tolower($1)}' w1800.txt |sort|uniq -c| awk '{print $1,$2, $1*1000000/1113084}' |sort -nr >w1800s.txt

## find the shared words and combined to produce a new file


awk 'FNR==NR{a[$2]=$3;next}{ print $0,a[$2]}' w1820n.txt w1810n.txt>w18210.txt
awk 'FNR==NR{a[$2]=$3;next}{ print $0,a[$2]}' w1810n.txt w1800n.txt>w18100.txt
...
awk 'FNR==NR{a[$2]=$3;next}{ print $0,a[$2]}' w1730n.txt w1720n.txt>w17320.txt
awk 'FNR==NR{a[$2]=$3;next}{ print $0,a[$2]}' w1720n.txt w1710n.txt>w17210.txt
awk 'FNR==NR{a[$2]=$3;next}{ print $0,a[$2]}' w1710n.txt w1700n.txt>w17100.txt



######### Step 2: enter R:



w1710=read.delim("w17100.txt", header=FALSE, sep=" ", stringsAsFactor=FALSE)
w1720=read.delim("w17210.txt", header=FALSE, sep=" ", stringsAsFactor=FALSE)
w1730=read.delim("w17320.txt", header=FALSE, sep=" ", stringsAsFactor=FALSE)
...
w1810=read.delim("w18100.txt", header=FALSE, sep=" ", stringsAsFactor=FALSE)
w1820=read.delim("w18210.txt", header=FALSE, sep=" ", stringsAsFactor=FALSE)
w1830=read.delim("w18320.txt", header=FALSE, sep=" ", stringsAsFactor=FALSE)
w1840=read.delim("w18430.txt", header=FALSE, sep=" ", stringsAsFactor=FALSE)
w1850=read.delim("w18540.txt", header=FALSE, sep=" ", stringsAsFactor=FALSE)
w1860=read.delim("w18650.txt", header=FALSE, sep=" ", stringsAsFactor=FALSE)



# remove those words with lower length

w1720=w1720[nchar(w1720$V2) >2 , ]
w1730=w1730[nchar(w1730$V2) >2 , ]
w1740=w1740[nchar(w1740$V2) >2 , ]
...
w1810=w1810[nchar(w1810$V2) >2 , ]
w1820=w1820[nchar(w1820$V2) >2 , ]
w1830=w1830[nchar(w1830$V2) >2 , ]
w1840=w1840[nchar(w1840$V2) >2,  ]



#remove stopwords
stopword=read.delim("stopword.txt1", header=FALSE, stringsAsFactor=FALSE)
stopword=stopword$V1


library(tm)



x=w1710$V2
x=removeWords(x,stopword)
w1710$V2=x

x=w1720$V2
x=removeWords(x,stopword)
w1720$V2=x

x=w1730$V2
x=removeWords(x,stopword)
w1730$V2=x

x=w1740$V2
x=removeWords(x,stopword)
w1740$V2=x

..

x=w1810$V2
x=removeWords(x,stopword)
w1810$V2=x

x=w1820$V2
x=removeWords(x,stopword)
w1820$V2=x

x=w1830$V2
x=removeWords(x,stopword)
w1830$V2=x

x=w1840$V2
x=removeWords(x,stopword)
w1840$V2=x



#find the shared word set between two period
#given the word frequency in latter period is 100 much more
#than the previous period according to the standard frequency

w1700s=w1700[which((w1700$V4-w1700$V3)>200),]
w1710s=w1710[which((w1710$V4-w1710$V3)>200),]
w1720s=w1720[which((w1720$V4-w1720$V3)>200),]
w1730s=w1730[which((w1730$V4-w1730$V3)>200),]
w1740s=w1740[which((w1740$V4-w1740$V3)>200),]
w1750s=w1750[which((w1750$V4-w1750$V3)>200),]
w1760s=w1760[which((w1760$V4-w1760$V3)>200),]
w1770s=w1770[which((w1770$V4-w1770$V3)>200),]
w1780s=w1780[which((w1780$V4-w1780$V3)>200),]
w1790s=w1790[which((w1790$V4-w1790$V3)>200),]
w1800s=w1800[which((w1800$V4-w1800$V3)>200),]
w1810s=w1810[which((w1810$V4-w1810$V3)>200),]
w1820s=w1820[which((w1820$V4-w1820$V3)>200),]
w1830s=w1830[which((w1830$V4-w1830$V3)>200),]
w1840s=w1840[which((w1840$V4-w1840$V3)>200),]






# remove blanket lines
w1710s=w1710s[which(w1710s$V2 !=""),]
w1720s=w1720s[which(w1720s$V2 !=""),]
w1730s=w1730s[which(w1730s$V2 !=""),]
w1740s=w1740s[which(w1740s$V2 !=""),]
w1750s=w1750s[which(w1750s$V2 !=""),]
w1760s=w1760s[which(w1760s$V2 !=""),]
w1770s=w1770s[which(w1770s$V2 !=""),]
w1780s=w1780s[which(w1780s$V2 !=""),]
w1790s=w1790s[which(w1790s$V2 !=""),]
w1800s=w1800s[which(w1800s$V2 !=""),]
w1810s=w1810s[which(w1810s$V2 !=""),]
w1820s=w1820s[which(w1820s$V2 !=""),]
w1830s=w1830s[which(w1830s$V2 !=""),]
w1840s=w1840s[which(w1840s$V2 !=""),]

head(w1810s)
#      V1           V2       V3       V4
#67  1604        first 1441.040 1887.360
#128  911     produced  818.447 1041.830
#134  872        stars  783.409 1014.230
#141  836 observations  751.066 1122.600
#154  764        given  686.381  889.492
#159  757       second  680.092 1201.330

# V1= raw freq in 1800, V2=lemma, V3=standard freq in 1800, V4=standard freq in 1810


## Welch test 
t.test(w1810$V3, w1810$V4)
#	Welch Two Sample t-test

#data:  w1810$V3 and w1810$V4
#t = -3.7161, df = 16521, p-value = 0.000203
#alternative hypothesis: true difference in means is not equal to 0
#95 percent confidence interval:
 -49.80308 -15.40728
#sample estimates:
#mean of x mean of y 
# 24.65830  57.26349 

###special processing for low p-value by adjusting the frequency difference

w1740s=w1740[which((w1740$V4-w1740$V3)>60),]
# p value= 0.0005173

w1750s=w1750[which((w1750$V4-w1750$V3)>60),]

w1770s=w1770[which((w1770$V4-w1770$V3)>60),]

w1850s=w1850[which((w1850$V4-w1850$V3)>100),]

w1860s=w1860[which((w1860$V4-w1860$V3)>100),]

w1740s=w1740s[which(w1740s$V2 !=""),]
w1750s=w1750s[which(w1750s$V2 !=""),]

w1770s=w1770s[which(w1770s$V2 !=""),]
w1850s=w1850s[which(w1850s$V2 !=""),]
w1860s=w1860s[which(w1860s$V2 !=""),]


## t-test 

w1770s=w1770[which((w1770$V4-w1770$V3)>150),]
w1770s=w1770s[which(w1770s$V2 !=""),]
t.test(w1770s$V3, w1770s$V4)

#	Welch Two Sample t-test

#data:  w1770s$V3 and w1770s$V4
#t = -2.7132, df = 122.85, p-value = 0.00762
#alternative hypothesis: true difference in means is not equal to 0
#95 percent confidence interval:
# -500.27431  -78.22607
#sample estimates:
#mean of x mean of y 
# 467.0377  756.2879 

##########Step 3: calculate relative entropy

## the function of entropy

 info <- function(CLASS.FREQ){
      freq.class <- CLASS.FREQ
      info <- 0
      for(i in 1:length(freq.class)){
        if(freq.class[[i]] != 0){ # zero check in class
          entropy <- -sum(freq.class[[i]] * log2(freq.class[[i]]))  #I calculate the entropy for each class i here
        }else{ 
          entropy <- 0
        } 
        info <- info + entropy # sum up entropy from all classes
      }
      return(info)
    }

    
    



enw4=info(w1710s$V3/sum(w1710s$V3))
enw4p=info(w1710s$V4/sum(w1710s$V4))

enw5=info(w1720s$V3/sum(w1720s$V3))
enw5p=info(w1720s$V4/sum(w1720s$V4))

enw6=info(w1730s$V3/sum(w1730s$V3))
enw6p=info(w1730s$V4/sum(w1730s$V4))

enw7=info(w1740s$V3/sum(w1740s$V3))
enw7p=info(w1740s$V4/sum(w1740s$V4))

enw8=info(w1750s$V3/sum(w1750s$V3))
enw8p=info(w1750s$V4/sum(w1750s$V4))

enw9=info(w1760s$V3/sum(w1760s$V3))
enw9p=info(w1760s$V4/sum(w1760s$V4))

enw10=info(w1770s$V3/sum(w1770s$V3))
enw10p=info(w1770s$V4/sum(w1770s$V4))

enw11=info(w1780s$V3/sum(w1780s$V3))
enw11p=info(w1780s$V4/sum(w1780s$V4))

enw12=info(w1790s$V3/sum(w1790s$V3))
enw12p=info(w1790s$V4/sum(w1790s$V4))


enw13=info(w1800s$V3/sum(w1800s$V3))
enw13p=info(w1800s$V4/sum(w1800s$V4))

enw14=info(w1810s$V3/sum(w1810s$V3))
#4.908081
enw14p=info(w1810s$V4/sum(w1810s$V4))
#5.390948

enw15=info(w1820s$V3/sum(w1820s$V3))
enw15p=info(w1820s$V4/sum(w1820s$V4))

enw16=info(w1830s$V3/sum(w1830s$V3))
enw16p=info(w1830s$V4/sum(w1830s$V4))

enw17=info(w1840s$V3/sum(w1840s$V3))
enw17p=info(w1840s$V4/sum(w1840s$V4))


## relative entropy
enw4p-enw4
enw5p-enw5
enw6p-enw6
enw7p-enw7
enw8p-enw8
enw9p-enw9
enw10p-enw10
enw11p-enw11
enw12p-enw12
enw13p-enw13
enw14p-enw14
#0.4828667
enw15p-enw15
enw16p-enw16
enw17p-enw17



##########step 4: Plot in R 

