########################################## 
## ���� id_decade_type.csv 
########################################## 
use Cwd; 
my $curdir = getcwd; 
 
open(F,"id_decade_type.csv"); 
while(<F>) 
{ 
    chop; $n++; 
    ($id,$de,$ty)=split /\t/; 
    $ty=~s/[\n\r]//; 
    if(-e "$curdir/type/$ty/$de"){} 
    else { 
         system("sudo mkdir -p $curdir/type/$ty/$de"); 
    }  
    $file="$curdir/type/$ty/$de/$id.txt"; 
    $cmd="sudo cp -f ./$id.txt ".$file; 
    system($cmd); 
} 
close Fo;
