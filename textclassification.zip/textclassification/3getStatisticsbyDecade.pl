###################################
##  ͳ�Ƹ�����ļ���
##################################
open(F,"id_decade_type.csv");
#open(F1,">same_decade1.csv");
$comp=1660;$n=0;$count=0;
while(<F>)
{
    chomp;
    ($file,$decade,$type)=split /\t/;
    if($comp ==$decade){$n++;$count++;}
    else{print $comp."\t".$n."\n";$comp=$decade;$n=1;$count++;}
}
close F1;
$count-=1;
print "total\t".$count."\n";